export const TABDATA = {
  RESOURCE: "resource",
  REQUEST: "request",
  USER: "user",
};
